$gamerule $(r) $(v)
