tag @s add aooni.loot
$item replace block ~ ~ ~ container.$(slot) with minecraft:paper[minecraft:custom_name={text:"비밀번호 쪽지 ①",color:"gold",italic:false},minecraft:lore=[{text:"접혀 있다. 집어서 펼쳐 보자",color:"white",italic:false}],minecraft:custom_data={aooni_fake:1b}]
