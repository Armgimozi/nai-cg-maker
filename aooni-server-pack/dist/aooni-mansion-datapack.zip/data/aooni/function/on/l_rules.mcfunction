function aooni:msg/rules
