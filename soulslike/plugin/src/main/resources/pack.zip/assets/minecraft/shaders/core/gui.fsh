#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec4 vertexColor;
in vec3 soulsFill;
in float soulsX;

out vec4 fragColor;

// Square Soul (pack/shaders.py): the flagged fills become deep vignettes with a little candle light from above (see gui.vsh).
void main() {
    vec4 color = vertexColor;
    if (soulsFill.z > 2.5) {
        // chat: warm ink that dissolves to the right instead of a hard black box
        color = vec4(vec3(0.0471, 0.0431, 0.0392), min(0.82, color.a * 1.5) * (1.0 - smoothstep(140.0, 330.0, soulsX)));
    } else if (soulsFill.z > 0.5) {
        vec2 p = soulsFill.xy;
        float r = length(p * vec2(0.86, 1.0));
        if (soulsFill.z < 1.5) {
            float a = mix(0.70, 0.98, smoothstep(0.25, 1.30, r));
            float candle = 1.0 - smoothstep(0.0, 1.0, length((p - vec2(0.0, 1.15)) * vec2(0.70, 1.40)));
            color = vec4(mix(vec3(0.0471, 0.0431, 0.0392), vec3(0.3608, 0.2745, 0.1569), 0.30 * candle), a - 0.12 * candle);
        } else {
            float a = mix(0.50, 0.97, smoothstep(0.20, 1.30, r));
            float low = smoothstep(0.1, -1.0, p.y);
            color = vec4(mix(vec3(0.0471, 0.0431, 0.0392), vec3(0.2392, 0.0588, 0.0471), 0.55 * low), a);
        }
    }
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
