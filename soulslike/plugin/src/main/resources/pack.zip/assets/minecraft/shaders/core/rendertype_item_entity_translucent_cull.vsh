#version 330

// Square Soul (pack/roll_figure.py). Vanilla 1.21.11 rendertype_item_entity_translucent_cull.vsh plus:
// soulsRel: the camera-relative position, for the roll stand-in marker test in the fragment shader;
// soulsCode / soulsIn: the radius the plugin codes into the low two bits of each tint channel (R, G, B -> 6 bits,
// radius = code * 0.05 blocks, codes 1..62; 0 and 63 = no code) and whether this vertex lies inside it.

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;


out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;
out vec3 soulsRel;
out float soulsIn;
flat out float soulsCode;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;
    soulsRel = Position;
    ivec3 bits = ivec3(Color.rgb * 255.0 + 0.5) & 3;
    int code = bits.r | (bits.g << 2) | (bits.b << 4);
    soulsCode = float(code);
    soulsIn = (code > 0 && code < 63 && length(Position) < float(code) * 0.0500) ? 1.0 : 0.0;
}
