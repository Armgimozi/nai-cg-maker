#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec2 UV0;
in vec4 Color;

out vec2 texCoord0;
out vec4 vertexColor;
out float soulsGui;

// Square Soul (pack/shaders.py): vanilla position_tex_color.vsh plus
//  * a flag for GUI quads (orthographic): the fragment shader reads their texture with an area filter;
//  * the in-game vignette (the only full-screen GUI quad with texture 0..1 on the screen corners, drawn in a grey below
//    white) is kept at least 0.800 strong, so the corners always close in (misc/vignette.png gives the shape).
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    texCoord0 = UV0;
    vertexColor = Color;
    soulsGui = ProjMat[3][3] == 1.0 ? 1.0 : 0.0;
    if (ProjMat[3][3] == 1.0 && Color.a > 0.999 && Color.r < 0.999 && Color.r == Color.g && Color.g == Color.b) {
        vec2 screen = vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]);
        vec2 at = (ModelViewMat * vec4(Position, 1.0)).xy;
        bool cornerX = (abs(at.x) < 0.01 && UV0.x == 0.0) || (abs(at.x - screen.x) < 0.51 && UV0.x == 1.0);
        bool cornerY = (abs(at.y) < 0.01 && UV0.y == 0.0) || (abs(at.y - screen.y) < 0.51 && UV0.y == 1.0);
        if (cornerX && cornerY) {
            vertexColor.rgb = vec3(mix(0.800, 1.0, Color.r));
        }
    }
}
