#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;

out vec4 vertexColor;
out vec3 soulsFill;
out float soulsX;

// Square Soul (pack/shaders.py): vanilla gui.vsh plus flags for a few vanilla fills:
// container screen dim (0xC0101010..0xD0101010) -> 1, death screen red wash (0x60500000 / 0xA0803030) -> 2,
// chat line backdrop (black, translucent) -> 3; the chat "system message" bar (0xD0D0D0) becomes bronze.
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;
    ivec4 c = ivec4(Color * 255.0 + 0.5);
    float mode = 0.0;
    if (c.rgb == ivec3(16, 16, 16) && (c.a == 192 || c.a == 208)) mode = 1.0;
    else if (c == ivec4(80, 0, 0, 96) || c == ivec4(128, 48, 48, 160)) mode = 2.0;
    else if (c.rgb == ivec3(208, 208, 208)) vertexColor = vec4(vec3(0.4902, 0.3765, 0.2039), Color.a * 0.85);
    else if (c.rgb == ivec3(0, 0, 0) && c.a > 0 && c.a < 200) mode = 3.0;
    soulsFill = vec3(gl_Position.xy / gl_Position.w, mode);
    soulsX = (gl_Position.x / gl_Position.w + 1.0) / ProjMat[0][0];
}
