#version 330

// Square Soul (pack/roll_figure.py). Vanilla 1.21.11 rendertype_item_entity_translucent_cull.fsh plus one block:
// texels whose alpha is a roll stand-in marker (240..249) belong to the copy of the roll stand-in that only the
// rolling player sees. Marker k = 249 - alpha gives a radius r = 0.40 + k * 0.35 blocks: the farthest any
// point drawn with that texture gets from that player's first-person camera. A fragment closer to the camera than r
// is dropped (first person: the camera sits inside the stand-in, so all of it is dropped); otherwise it is drawn
// opaque (third person: the camera is 4 blocks away, nothing is dropped). No other texture uses these alphas.

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;
in vec3 soulsRel;

out vec4 fragColor;

void main() {
    vec4 tex = texture(Sampler0, texCoord0);
    float mark = floor(tex.a * 255.0 + 0.5);
    if (mark >= 240.0 && mark <= 249.0) {
        if (length(soulsRel) < 0.4000 + (249.0 - mark) * 0.3500) {
            discard;
        }
        tex.a = 1.0;
    }
    vec4 color = tex * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
