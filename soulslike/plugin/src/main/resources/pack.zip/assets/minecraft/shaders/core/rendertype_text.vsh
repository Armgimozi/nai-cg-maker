#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// Square Soul HUD (pack/hud.py). Vanilla 1.21.11 rendertype_text.vsh plus one block:
// GUI text (orthographic projection) whose colour is a HUD marker 254 253 b is moved (whole GUI pixels):
//   b 1: HUD bars (boss bar name, drawn from the screen centre minus 205, top at y 8)
//          -> left edge + 0.0450 x width, top edge + 0.0500 x height
//   b 2: souls box (action bar, right end at the screen centre plus 206, bottom 8 above the screen bottom)
//          -> right edge - 0.0400 x width, bottom edge - 0.0400 x height
//   b 3 / 4 / 5: boss bar glyphs / boss name / boss name shadow on boss bar line k (top 3 + 19 k)
//          -> line top at the screen bottom - 64 (stacked 24 up per extra boss); the bar glyphs are
//             stretched around the screen centre to about 0.4500 x width (200 wide, 1 to 2.5 in quarter steps),
//             the name moves with the bar's left end. Name -> beige, shadow -> dark
//   b 6: hidden (alpha 0): the boss name copy that only cancels the name width
// Other marker glyphs keep their own colours (vertex colour replaced by white).
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    ivec3 mark = ivec3(Color.rgb * 255.0 + 0.5);
    if (mark.r == 254 && mark.g == 253 && mark.b >= 1 && mark.b <= 6 && ProjMat[3][3] == 1.0) {
        float guiWidth = ceil(2.0 / ProjMat[0][0] - 0.01);
        float guiHeight = ceil(-2.0 / ProjMat[1][1] - 0.01);
        float centre = floor(guiWidth * 0.5);
        vec2 at = (ModelViewMat * vec4(Position, 1.0)).xy;
        vec2 shift = vec2(0.0);
        vec4 ink = vec4(1.0, 1.0, 1.0, Color.a);
        if (mark.b == 1) {
            shift.x = floor(guiWidth * 0.0450 + 0.5) - (centre - 205.0);
            shift.y = floor(guiHeight * 0.0500 + 0.5) - 8.0;
        } else if (mark.b == 2) {
            shift.x = (guiWidth - floor(guiWidth * 0.0400 + 0.5)) - (centre + 206.0);
            shift.y = 8.0 - floor(guiHeight * 0.0400 + 0.5);
        } else if (mark.b == 6) {
            ink.a = 0.0;
        } else {
            float line = floor((at.y - 2.0) / 19.0);
            float slot = max(line, 1.0) - 1.0;
            shift.y = (guiHeight - 64.0 - slot * 24.0) - (3.0 + 19.0 * line);
            float s = clamp(floor(guiWidth * 0.4500 / 200.0 * 4.0 + 0.5) / 4.0, 1.0, 2.5);
            if (mark.b == 3) {
                shift.x = (at.x - centre) * (s - 1.0);
            } else {
                shift.x = -floor((s - 1.0) * 200.0 * 0.5 + 0.5);
                ink = mark.b == 4 ? vec4(0.8196, 0.7647, 0.6275, Color.a) : vec4(0.0471, 0.0431, 0.0392, Color.a * 0.7843);
            }
        }
        gl_Position.x += shift.x * ProjMat[0][0];
        gl_Position.y += shift.y * ProjMat[1][1];
        vertexColor = ink * texelFetch(Sampler2, UV2 / 16, 0);
    }
}
