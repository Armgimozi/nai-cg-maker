#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// Square Soul HUD (pack/hud.py). Vanilla 1.21.11 rendertype_text.vsh plus one block:
// GUI text (orthographic projection) whose colour is a HUD marker is moved to a screen edge.
//   marker 254 253 1: HUD bars (boss bar name, drawn from the screen centre minus 205) -> left edge + 8
//   marker 254 253 2: souls box (action bar, right end at the screen centre plus 206) -> right edge - 8
// The marker colour is replaced by white so the glyph keeps its own colours.
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    ivec3 mark = ivec3(Color.rgb * 255.0 + 0.5);
    if (mark.r == 254 && mark.g == 253 && (mark.b == 1 || mark.b == 2) && ProjMat[3][3] == 1.0) {
        float guiWidth = ceil(2.0 / ProjMat[0][0] - 0.01);
        float centre = floor(guiWidth * 0.5);
        float shift = mark.b == 1 ? (8.0 - (centre - 205.0)) : ((guiWidth - 8.0) - (centre + 206.0));
        gl_Position.x += shift * ProjMat[0][0];
        vertexColor = vec4(1.0, 1.0, 1.0, Color.a) * texelFetch(Sampler2, UV2 / 16, 0);
    }
}
