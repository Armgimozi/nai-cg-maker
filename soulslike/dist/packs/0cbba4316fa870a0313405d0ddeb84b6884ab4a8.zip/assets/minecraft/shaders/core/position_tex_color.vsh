#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec2 UV0;
in vec4 Color;

uniform sampler2D Sampler0;

out vec2 texCoord0;
out vec4 vertexColor;
out float soulsGui;

// Block Soul (pack/shaders.py): vanilla position_tex_color.vsh plus
//  * a flag for GUI quads (orthographic): the fragment shader reads their texture with an area filter;
//  * the in-game vignette (the only full-screen GUI quad with texture 0..1 on the screen corners, drawn in a grey below
//    white) is kept at least 0.800 strong, so the corners always close in (misc/vignette.png gives the shape);
//  * no slot highlight on the three erased slots of the player inventory (its 2x2 crafting grid is two ring slots now:
//    only the left column is drawn, DESIGN 9.4). The client still hovers the right column and the result slot. The two
//    highlight sprites (container/slot_highlight_back, _front, 24x24 drawn as one quad) carry an invisible mark in each
//    corner texel (alpha 1, a different ash colour per corner, pack/gui_skin.py HIGHLIGHT_MARKS). A vertex reads the texel
//    half a texel inside each diagonal of its UV; the mark it finds tells which corner it is, hence the quad origin. If
//    that origin is an erased slot (slot - 4) of a 176x166 screen centred like the inventory (recipe book shut, or open
//    and pushed right), the vertex goes off screen, so the whole quad is dropped.
//    The test only knows positions, not screens, so another screen loses the highlight on a slot that lands exactly on an
//    erased one (DESIGN 9.4 known limit 2): the hopper (176x133) fifth slot (116,20) at even scaled GUI heights, the
//    shulker box (176x167) slots (116,18) and (116,36) at odd scaled heights, and the donkey, mule and llama chest
//    slots (116,18) and (116,36). Chests, barrels, ender chests (168 tall) and the furnace result (116,35) never land.

bool soulsMark(vec2 uv, ivec3 rgb) {
    ivec4 t = ivec4(textureLod(Sampler0, uv, 0.0) * 255.0 + 0.5);
    return t.a == 1 && t.rgb == rgb;
}

bool soulsErasedSlot(vec2 o) {
    vec2 screen = ceil(vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]) - 0.01);
    float top = floor((screen.y - 166.0) / 2.0);
    for (int k = 0; k < 2; k++) {
        float left = floor((screen.x - 176.0) / 2.0);
        if (k == 1) {
            if (screen.x < 379.0) break;
            left = 177.0 + floor((screen.x - 376.0) / 2.0);
        }
        vec2 p = o - vec2(left, top);
        if (all(lessThan(abs(p - vec2(112.0, 14.0)), vec2(0.01)))) return true;
        if (all(lessThan(abs(p - vec2(112.0, 32.0)), vec2(0.01)))) return true;
        if (all(lessThan(abs(p - vec2(150.0, 24.0)), vec2(0.01)))) return true;
    }
    return false;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    if (ProjMat[3][3] == 1.0) {
        vec2 h = 0.5 / vec2(textureSize(Sampler0, 0));
        vec2 at = (ModelViewMat * vec4(Position, 1.0)).xy;
        vec2 o = vec2(-1000.0);
        if (soulsMark(UV0 + vec2(h.x, h.y), ivec3(28, 27, 26))) o = at;
        else if (soulsMark(UV0 + vec2(-h.x, h.y), ivec3(58, 56, 54))) o = at - vec2(24.0, 0.0);
        else if (soulsMark(UV0 + vec2(h.x, -h.y), ivec3(92, 89, 85))) o = at - vec2(0.0, 24.0);
        else if (soulsMark(UV0 + vec2(-h.x, -h.y), ivec3(133, 128, 121))) o = at - vec2(24.0, 24.0);
        if (o.x > -999.0 && soulsErasedSlot(o)) {
            gl_Position = vec4(3.0, 3.0, 0.0, 1.0);
        }
    }

    texCoord0 = UV0;
    vertexColor = Color;
    soulsGui = ProjMat[3][3] == 1.0 ? 1.0 : 0.0;
    if (ProjMat[3][3] == 1.0 && Color.a > 0.999 && Color.r < 0.999 && Color.r == Color.g && Color.g == Color.b) {
        vec2 screen = vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]);
        vec2 at = (ModelViewMat * vec4(Position, 1.0)).xy;
        bool cornerX = (abs(at.x) < 0.01 && UV0.x == 0.0) || (abs(at.x - screen.x) < 0.51 && UV0.x == 1.0);
        bool cornerY = (abs(at.y) < 0.01 && UV0.y == 0.0) || (abs(at.y - screen.y) < 0.51 && UV0.y == 1.0);
        if (cornerX && cornerY) {
            vertexColor.rgb = vec3(mix(0.800, 1.0, Color.r));
        }
    }
}
