#version 330

#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

// Block Soul (pack/shaders.py): vanilla rendertype_text_see_through.fsh; our glyph texels (B = 1, alpha 0) carry
// their coverage in R (pack/fonts.py).
void main() {
    vec4 t = texture(Sampler0, texCoord0);
    if (abs(t.b * 255.0 - 1.0) < 0.5 && t.a * 255.0 < 1.5) t = vec4(1.0, 1.0, 1.0, t.r);
    vec4 color = t * vertexColor;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = color * ColorModulator;
}
