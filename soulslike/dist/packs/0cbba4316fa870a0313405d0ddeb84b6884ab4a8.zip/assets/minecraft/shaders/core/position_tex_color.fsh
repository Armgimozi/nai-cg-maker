#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

uniform sampler2D Sampler0;

in vec2 texCoord0;
in vec4 vertexColor;
in float soulsGui;

out vec4 fragColor;

// Block Soul (pack/shaders.py): vanilla position_tex_color.fsh, but GUI sprites are read with an area (box) filter over the
// texels the screen pixel covers. Our UI art is drawn at 2 texels per GUI pixel; at GUI scale 3 a texel is 1.5 screen
// pixels and nearest sampling made lines 1 or 2 pixels thick by position. 1:1 art is unchanged.
void main() {
    vec4 color;
    vec2 size = vec2(textureSize(Sampler0, 0));
    vec2 t = texCoord0 * size;
    vec2 fp = clamp(vec2(abs(dFdx(t).x) + abs(dFdy(t).x), abs(dFdx(t).y) + abs(dFdy(t).y)), vec2(0.001), vec2(4.0));
    // one texel per screen pixel (items from the GUI item atlas, 2x art at GUI scale 2, 1x art at scale 1): plain nearest
    // like vanilla, so a quad that is not texel-aligned never bleeds a neighbouring atlas cell into its edge
    bool oneToOne = all(greaterThan(fp, vec2(0.99))) && all(lessThan(fp, vec2(1.01)));
    if (soulsGui > 0.5 && !oneToOne) {
        vec2 lo = t - 0.5 * fp;
        vec2 hi = t + 0.5 * fp;
        ivec2 i0 = ivec2(floor(lo));
        ivec2 i1 = ivec2(ceil(hi)) - 1;
        ivec2 hiT = ivec2(size) - 1;
        vec4 prem = vec4(0.0);
        for (int y = i0.y; y <= i1.y; y++) {
            float wy = min(hi.y, float(y + 1)) - max(lo.y, float(y));
            if (wy <= 0.0) continue;
            for (int x = i0.x; x <= i1.x; x++) {
                float wx = min(hi.x, float(x + 1)) - max(lo.x, float(x));
                if (wx <= 0.0) continue;
                vec4 s = texelFetch(Sampler0, clamp(ivec2(x, y), ivec2(0), hiT), 0);
                prem += wx * wy * vec4(s.rgb * s.a, s.a);
            }
        }
        prem /= fp.x * fp.y;
        color = prem.a > 0.0 ? vec4(prem.rgb / prem.a, prem.a) : vec4(0.0);
        color *= vertexColor;
    } else {
        color = texture(Sampler0, texCoord0) * vertexColor;
    }
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
