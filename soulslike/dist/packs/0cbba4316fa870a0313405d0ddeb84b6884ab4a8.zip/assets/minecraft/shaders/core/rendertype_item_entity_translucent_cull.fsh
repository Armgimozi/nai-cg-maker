#version 330

// Block Soul (pack/roll_figure.py). Vanilla 1.21.11 rendertype_item_entity_translucent_cull.fsh plus one block:
// texels whose alpha (read at mip level 0) is a roll stand-in marker (240..249) belong to the copy of the roll
// stand-in that only the rolling player sees. If the plugin coded a radius into the tint (soulsCode 1..62, see the .vsh),
// a triangle is dropped when all three of its corners lie inside that radius around the camera (soulsIn interpolates to 1);
// otherwise the whole triangle is drawn opaque. The radius is the farthest that part gets from the player's first-person
// camera while that pose is shown, so in first person every corner is inside and nothing of the stand-in is drawn; the
// third-person camera is 4 blocks away and draws all of it. Without a code (held items: untinted, code 63) the marker
// k = 249 - alpha gives a fixed radius r = 0.40 + k * 0.35 blocks tested per fragment.
// No other texture in the item and block atlases uses these alphas.

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;
in vec3 soulsRel;
in float soulsIn;
flat in float soulsCode;

out vec4 fragColor;

void main() {
    vec4 tex = texture(Sampler0, texCoord0);
    float mark = floor(textureLod(Sampler0, texCoord0, 0.0).a * 255.0 + 0.5);
    if (mark >= 240.0 && mark <= 249.0) {
        if (soulsCode > 0.5 && soulsCode < 62.5) {
            if (soulsIn > 0.999) {
                discard;
            }
        } else if (length(soulsRel) < 0.4000 + (249.0 - mark) * 0.3500) {
            discard;
        }
        tex.a = 1.0;
    }
    vec4 color = tex * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
