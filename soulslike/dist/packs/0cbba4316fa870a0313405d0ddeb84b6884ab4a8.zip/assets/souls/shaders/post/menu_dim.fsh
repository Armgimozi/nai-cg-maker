#version 330

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

in vec2 texCoord;

out vec4 fragColor;

// Block Soul (pack/shaders.py): after the vanilla menu blur, drain the colour, darken, close in with a heavy vignette and
// let a little warm candle light fall from above.
void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    vec2 p = texCoord * 2.0 - 1.0;
    float aspect = OutSize.x / max(OutSize.y, 1.0);
    float r = length(vec2(p.x * min(aspect, 1.9) / 1.6, p.y));
    float lum = dot(c, vec3(0.299, 0.587, 0.114));
    vec3 col = mix(c, vec3(lum) * vec3(0.6902, 0.6510, 0.5569) * 1.5, 0.5);
    col *= mix(0.55, 0.08, smoothstep(0.15, 1.25, r));
    float candle = 1.0 - smoothstep(0.0, 1.0, length((p - vec2(0.0, 1.15)) * vec2(0.65, 1.35)));
    col += vec3(0.3608, 0.2745, 0.1569) * 0.18 * candle;
    fragColor = vec4(col, 1.0);
}
