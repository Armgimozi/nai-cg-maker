#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in float soulsShadow;
in float soulsGui;
in float soulsDeathT;

out vec4 fragColor;

// Square Soul (pack/shaders.py): vanilla rendertype_text.fsh, but GUI glyphs are
// read with an area (box) filter over the texels the screen pixel covers. Our pre-rasterised serif glyphs
// (pack/fonts.py: 4 texels per GUI pixel, coverage in R, B = 1 and alpha 0 as the marker) come out
// identical at every position on GUI scales 2, 3 and 4; pixel art at 1 texel per GUI pixel is unchanged.
bool mine(vec4 t) {
    return abs(t.b * 255.0 - 1.0) < 0.5 && t.a * 255.0 < 1.5;
}

// the YOU DIED band (pack/hud.py death_band): an alpha map whose texels are all RGB (0, 0, 2), painted ink here.
// Its soft tails are kept (no 0.1 cut) and the vanilla shadow copy is not drawn (the band would double up).
bool band(vec4 t) {
    return t.r * 255.0 < 0.5 && t.g * 255.0 < 0.5 && abs(t.b * 255.0 - 2.0) < 0.5;
}

void main() {
    vec2 size = vec2(textureSize(Sampler0, 0));
    vec2 t = texCoord0 * size;
    ivec2 hiT = ivec2(size) - 1;
    vec4 centre = texelFetch(Sampler0, clamp(ivec2(floor(t)), ivec2(0), hiT), 0);
    bool ours = mine(centre);
    bool isBand = band(centre);
    vec4 color;
    if (soulsGui > 0.5) {
        if (isBand && soulsShadow > 0.5) {
            discard;
        }
        vec2 fp = clamp(vec2(abs(dFdx(t).x) + abs(dFdy(t).x), abs(dFdx(t).y) + abs(dFdy(t).y)), vec2(0.001), vec2(6.0));
        // shadow of our glyphs: the same coverage box-blurred over 2.5 more texels (a soft ink halo)
        vec2 fq = (ours && soulsShadow > 0.5) ? fp + vec2(2.5) : fp;
        vec2 lo = t - 0.5 * fq;
        vec2 hi = t + 0.5 * fq;
        ivec2 i0 = ivec2(floor(lo));
        ivec2 i1 = ivec2(ceil(hi)) - 1;
        float cov = 0.0;
        vec4 prem = vec4(0.0);
        for (int y = i0.y; y <= i1.y; y++) {
            float wy = min(hi.y, float(y + 1)) - max(lo.y, float(y));
            if (wy <= 0.0) continue;
            for (int x = i0.x; x <= i1.x; x++) {
                float wx = min(hi.x, float(x + 1)) - max(lo.x, float(x));
                if (wx <= 0.0) continue;
                vec4 s = texelFetch(Sampler0, clamp(ivec2(x, y), ivec2(0), hiT), 0);
                float w = wx * wy;
                if (ours) {
                    cov += w * (mine(s) ? s.r : 0.0);
                } else {
                    prem += w * vec4(s.rgb * s.a, s.a);
                }
            }
        }
        if (ours) {
            cov = clamp(cov / (fq.x * fq.y), 0.0, 1.0);
            cov = soulsShadow > 0.5 ? min(1.0, cov * 2.2) : pow(cov, 0.860);
            color = vec4(1.0, 1.0, 1.0, cov);
        } else if (isBand) {
            color = vec4(vec3(0.0471, 0.0431, 0.0392), prem.a / (fp.x * fp.y));
        } else {
            prem /= fp.x * fp.y;
            color = prem.a > 0.0 ? vec4(prem.rgb / prem.a, prem.a) : vec4(0.0);
            if (color.a < 0.1) color.a = 0.0;
        }
        color *= vertexColor * ColorModulator;
        if (soulsDeathT < 1.0e5) {
            // fading YOU DIED: the band first, the letters out of it (ticks since death, see rendertype_text.vsh)
            color.a *= isBand ? smoothstep(2.0, 18.0, soulsDeathT)
                              : smoothstep(6.0, 26.0, soulsDeathT);
        }
        if (color.a < 0.004) {
            discard;
        }
    } else {
        if (ours) {
            // world text (signs, name tags): bilinear coverage
            vec2 p = t - 0.5;
            ivec2 b = ivec2(floor(p));
            vec2 f = p - vec2(b);
            float c00 = texelFetch(Sampler0, clamp(b, ivec2(0), hiT), 0).r;
            float c10 = texelFetch(Sampler0, clamp(b + ivec2(1, 0), ivec2(0), hiT), 0).r;
            float c01 = texelFetch(Sampler0, clamp(b + ivec2(0, 1), ivec2(0), hiT), 0).r;
            float c11 = texelFetch(Sampler0, clamp(b + ivec2(1, 1), ivec2(0), hiT), 0).r;
            float cov = mix(mix(c00, c10, f.x), mix(c01, c11, f.x), f.y);
            color = vec4(1.0, 1.0, 1.0, cov) * vertexColor * ColorModulator;
        } else {
            color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
        }
        if (color.a < 0.1) {
            discard;
        }
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
