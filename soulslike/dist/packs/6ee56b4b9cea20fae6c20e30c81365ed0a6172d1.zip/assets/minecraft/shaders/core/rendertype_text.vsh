#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out float soulsShadow;
out float soulsGui;
out float soulsDeathT;

// Square Soul HUD (pack/hud.py). Vanilla 1.21.11 rendertype_text.vsh plus one block:
// GUI text (orthographic projection) whose colour is a HUD marker 254 253 b is moved (whole GUI pixels):
//   b 1: HUD bars (boss bar name, drawn from the screen centre minus 205, top at y 8)
//          -> left edge + 0.0450 x width, top edge + 0.0500 x height
//   b 2: souls box (action bar, right end at the screen centre plus 206, bottom 8 above the screen bottom)
//          -> right edge - 0.0400 x width, bottom edge - 0.0400 x height
//   b 3 / 4 / 5 / 7: boss bar glyphs / boss name / boss name shadow / boss bar end caps on boss bar line k
//          (top 3 + 19 k) -> line top at the screen bottom - 64 (stacked 24 up per extra boss); the bar glyphs are
//          stretched around the screen centre to about 0.4500 x width (200 wide, 1 to 2.5 in quarter steps),
//          the caps move rigidly with the stretched bar ends, the name moves with the bar's left end.
//          Name -> beige, shadow -> dark
//   b 6: hidden (alpha 0): the boss name copy that only cancels the name width
// Other marker glyphs keep their own colours (vertex colour replaced by white).
void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    soulsGui = ProjMat[3][3] == 1.0 ? 1.0 : 0.0;

    // Square Soul (pack/shaders.py): GUI text colours and shadows.
    soulsShadow = 0.0;
    soulsDeathT = 1.0e6;
    if (ProjMat[3][3] == 1.0) {
        ivec3 rgbi = ivec3(Color.rgb * 255.0 + 0.5);
        bool hudMark = rgbi.r == 254 && rgbi.g == 253 && rgbi.b >= 1 && rgbi.b <= 7;
        int hiC = max(rgbi.r, max(rgbi.g, rgbi.b));
        vec4 light = texelFetch(Sampler2, UV2 / 16, 0);
        bool deathMain = rgbi.r == 254 && rgbi.g >= 144 && rgbi.g <= 144 + 93;
        bool deathShadow = rgbi.r == 253 && rgbi.g >= 144 && rgbi.g <= 144 + 93;
        if (deathMain || deathShadow) {
            // fading YOU DIED (death screen message line, pack/hud.py): the colour carries the game time of death
            // t = (g - G0) * 256 + b (game time % 24000); ticks since death -> the fragment shader fades band and letters in
            float t0 = float((rgbi.g - 144) * 256 + rgbi.b);
            float dt = GameTime * 24000.0 - t0;
            if (dt < -12000.0) dt += 24000.0;
            else if (dt > 12000.0) dt -= 24000.0;
            soulsDeathT = (dt < -100.0 || dt > 100.0) ? 1.0e6 : dt;
            if (deathShadow) {
                // like the death screen title's shadow (2x: 2 GUI px, see below -0.5): 1.5 GUI px right and down, ink
                soulsShadow = 1.0;
                vertexColor = vec4(vec3(0.0471, 0.0431, 0.0392), Color.a * 0.800) * light;
                gl_Position.x += 0.5 * ProjMat[0][0];
                gl_Position.y += 0.5 * ProjMat[1][1];
            } else {
                vertexColor = vec4(vec3(0.8392, 0.7961, 0.6902), Color.a) * light;
            }
        } else if ((!hudMark && hiC <= 63 && hiC > 0) || (hudMark && rgbi.b == 5)) {
            // shadow copy (text colour x 0.25, drawn 1 GUI px right and down): half a pixel instead, warm ink halo
            soulsShadow = 1.0;
            if (!hudMark) vertexColor = vec4(vec3(0.0471, 0.0431, 0.0392), Color.a * 0.800) * light;
            gl_Position.x -= 0.5 * ProjMat[0][0];
            gl_Position.y -= 0.5 * ProjMat[1][1];
        } else if (!hudMark) {
            vec3 ink = Color.rgb;
            if (rgbi == ivec3(255, 255, 255)) ink = vec3(0.8392, 0.7961, 0.6902);
            else if (rgbi == ivec3(170, 170, 170)) ink = vec3(0.7020, 0.6392, 0.4980);
            else if (rgbi == ivec3(160, 160, 160)) ink = vec3(0.5216, 0.5020, 0.4745);
            else if (rgbi == ivec3(224, 224, 224)) ink = vec3(0.8392, 0.7961, 0.6902);
            else if (rgbi == ivec3(85, 85, 85)) ink = vec3(0.4196, 0.3725, 0.2902);
            else if (rgbi == ivec3(64, 64, 64)) ink = vec3(0.7020, 0.6392, 0.4980);
            else if (rgbi == ivec3(255, 255, 85)) ink = vec3(0.8196, 0.7647, 0.6275);
            else if (rgbi == ivec3(255, 255, 0) || rgbi == ivec3(255, 136, 255)) ink = vec3(0.8196, 0.7647, 0.6275);
            else if (rgbi == ivec3(255, 255, 160)) ink = vec3(0.9020, 0.8275, 0.6039);
            vertexColor = vec4(ink, Color.a) * light;
        }
    }

    ivec3 mark = ivec3(Color.rgb * 255.0 + 0.5);
    if (mark.r == 254 && mark.g == 253 && mark.b >= 1 && mark.b <= 7 && ProjMat[3][3] == 1.0) {
        float guiWidth = ceil(2.0 / ProjMat[0][0] - 0.01);
        float guiHeight = ceil(-2.0 / ProjMat[1][1] - 0.01);
        float centre = floor(guiWidth * 0.5);
        vec2 at = (ModelViewMat * vec4(Position, 1.0)).xy;
        vec2 shift = vec2(0.0);
        vec4 ink = vec4(1.0, 1.0, 1.0, Color.a);
        if (mark.b == 1) {
            shift.x = floor(guiWidth * 0.0450 + 0.5) - (centre - 205.0);
            shift.y = floor(guiHeight * 0.0500 + 0.5) - 8.0;
        } else if (mark.b == 2) {
            shift.x = (guiWidth - floor(guiWidth * 0.0400 + 0.5)) - (centre + 206.0);
            shift.y = 8.0 - floor(guiHeight * 0.0400 + 0.5);
        } else if (mark.b == 6) {
            ink.a = 0.0;
        } else {
            float line = floor((at.y - 2.0) / 19.0);
            float slot = max(line, 1.0) - 1.0;
            shift.y = (guiHeight - 64.0 - slot * 24.0) - (3.0 + 19.0 * line);
            float s = clamp(floor(guiWidth * 0.4500 / 200.0 * 4.0 + 0.5) / 4.0, 1.0, 2.5);
            if (mark.b == 3) {
                shift.x = (at.x - centre) * (s - 1.0);
            } else if (mark.b == 7) {
                shift.x = sign(at.x - centre) * floor((s - 1.0) * 100.0 + 0.5);
            } else {
                shift.x = -floor((s - 1.0) * 200.0 * 0.5 + 0.5);
                ink = mark.b == 4 ? vec4(0.8196, 0.7647, 0.6275, Color.a) : vec4(0.0471, 0.0431, 0.0392, Color.a * 0.7843);
            }
        }
        gl_Position.x += shift.x * ProjMat[0][0];
        gl_Position.y += shift.y * ProjMat[1][1];
        vertexColor = ink * texelFetch(Sampler2, UV2 / 16, 0);
    }
}
